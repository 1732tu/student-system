package com.example.demo1.boda.dao;
import java.sql.*;

public class MySQLConnectionExample {
    public static void main(String[] args) {
        // 数据库连接信息
        String url = "jdbc:mysql://localhost:3306/elearningDS";
        String username = "root";
        String password = "123456";

        // 使用 try-with-resources 语句自动关闭资源
        try (Connection conn = DriverManager.getConnection(url, username, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM yourtable")) {

            // 输出 MySQL 服务器版本
            DatabaseMetaData metaData = conn.getMetaData();
            System.out.println("数据库产品名称: " + metaData.getDatabaseProductName());
            System.out.println("数据库产品版本: " + metaData.getDatabaseProductVersion());

            // 处理查询结果
            while (rs.next()) {
                // 根据表结构修改列名和数据类型
                System.out.println("ID: " + rs.getInt("id") +
                        ", Name: " + rs.getString("name") +
                        ", Brand: " + rs.getString("brand")+
                        ", Price: " + rs.getDouble("price")
                );
            }

        } catch (SQLException e) {
            // 处理数据库连接异常
            System.err.println("数据库连接错误: " + e.getMessage());
            System.err.println("SQL状态: " + e.getSQLState());
            System.err.println("错误代码: " + e.getErrorCode());
            e.printStackTrace();
        }
    }
}